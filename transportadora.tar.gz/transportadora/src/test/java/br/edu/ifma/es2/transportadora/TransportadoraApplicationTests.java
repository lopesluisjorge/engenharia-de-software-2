package br.edu.ifma.es2.transportadora;

class TransportadoraApplicationTests {

    void contextLoads() {

    }

}
